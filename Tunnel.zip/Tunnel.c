/*
 * Programmer Name: Rachel Poppe
 * Username: 		rmpoppe
 * Program:			Tunnel
 * Description:		This program, given a 2D array of ints, will trace the easiest path from the left
 * 					side of a specified row to the right side.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void printArray(int* pArray, int maxCols, int maxRows)
{
	//print each row
	for (int i = 0; i < maxRows; i++)
	{
		//print each value in the row
		for (int j = 0; j < maxCols; j++)
		{
			if (pArray[i * maxCols + j] == 10)
				printf(".");
			else
				// val = *pA(row * numCols + col)
				printf("%d", pArray[i * maxCols + j]);
		}

		printf("\b\n");
	}
}


int main(int argc, char** argv)
{
	int verbose;
	if (argc < 2)
	{
		printf("Tunnel <start row> [verbose]\n");
		return 0;
	}
	if (argc > 2)
		verbose = atoi(argv[2]);
	else
		verbose = 0;

	int totalNumCol;
	int totalNumRow;
	scanf("%d %d", &totalNumRow, &totalNumCol);

	int totalNumValues = totalNumCol * totalNumRow;
	int vals[totalNumRow][totalNumCol];
	int maxCost = 0;
	int minVal = INT_MAX;
	int maxVal = 0;

	// Fill the 2D array of difficulty values
	for (int i = 0; i < totalNumRow; i++)
	{
		for (int j = 0; j < totalNumCol; j++)
		{
			int val;
			scanf("%d", &val);
			vals[i][j] = val;
			maxCost += val;
			if (val < minVal)
				minVal = val;
			if (val > maxVal)
				maxVal = val;
		}
	}

	if(atoi(argv[1]) >= totalNumCol)
	{
		printf("Invalid starting row!\n");
		return 0;
	}

	printf("Data points: %d\n", totalNumValues);
	printf("Avg difficulty: %.3f\n", (double)maxCost / totalNumValues);
	printf("Min difficulty: %d\n", minVal);
	printf("Max difficulty: %d\n\n", maxVal);


	int row = atoi(argv[1]);
	int col = 0;
	int length = 1;
	int cost = vals[row][col];
	vals[row][col] = 10;
	if (verbose)
	{
		printArray(&vals[0][0], totalNumCol, totalNumRow);
		printf("\n");
	}

	while ( col < totalNumCol-1)
	{

		//set direction values
		int rightVal = vals[row][col + 1];
		int upVal, downVal, leftVal;
		if(row != 0)
			upVal = vals[row-1][col];
		else
			upVal = 10;

		if(row != totalNumRow-1)
			downVal = vals[row+1][col];
		else
			downVal = 10;

		if(col != 0)
			leftVal = vals[row][col-1];
		else
			leftVal = 10;

		//if you have dug in all the areas around you, exit the loop
		if (rightVal > 9 && leftVal > 9 && upVal > 9 && downVal > 9)
		{
			vals[row][col] = 10;
			break;
		}
		//find the min and update current position
		if (rightVal <= upVal && rightVal <= downVal && rightVal <= leftVal)
			col++;
		else if (downVal <= upVal && downVal <= rightVal && downVal <= leftVal)
			row++;
		else if (upVal <= rightVal && upVal <= downVal && upVal <= leftVal)
			row--;
		else
			col--;
		//update length, cost, and value at current position
		length++;
		cost += vals[row][col];
		vals[row][col] = 10;
		//check if "verbose" and print
		if(verbose)
		{
			printArray(&vals[0][0], totalNumCol, totalNumRow);
			printf("\n");
		}
	}

	if (!verbose)
	{
		printArray(&vals[0][0], totalNumCol, totalNumRow);
		printf("\n");
	}

	printf("Length = %d\nCost = %d", length, cost);

	return 0;
}

